import java.util.*;

public class Main {
    public static void main(String[] args) {

        //Пример1.1я часть
        class Fish {
            String name;
            double price;
            double weight;

            public Fish(String name, double weight, double price) {
                this.name = name;
                this.price = price;
                this.weight = weight;
            }

            @Override
            public boolean equals(Object o) {
                if (o == this) {
                    return true;
                }
                if (!(o instanceof Fish)) {
                    return false;
                }
                Fish tmp = (Fish) o;
                return (tmp.name.equals(this.name)) && (tmp.weight == this.weight && tmp.price == (this.price));
            }

            public int hashCode() {
                return this.name.hashCode();
            }

            public double getPrice() {
                return price;

            }

            public double getWeight() {
                return weight;

            }

            @Override
            public String toString() {
                return this.name + "Вес: " + this.weight + "Цена: " + this.price;
            }


            //Пример.2. Сортировка
//            Map<String, String> tm = new TreeMap<>();
//        tm.put("France","Paris");
//        tm.put("Brazil","Brazilia");
//        tm.put("Canada","Otawa");
//        tm.put("Denmark","Copengagen");
//        tm.put("Russia","Moscow");
//        tm.put("Sweden","Stockholm");
//
//        for(Map.Entry e :tm.entrySet())
//            {
//                System.out.println(e.getKey() + " " + e.getValue());
//            }
//
//            Iterator iterator = tm.entrySet().iterator();
//        while(iterator.hasNext())
//
//            {
//                Map.Entry entry = (Map.Entry) iterator.hasNext();
//                String key = (String) entry.getValue();
//                String value = (String) entry.getValue();
//
//                System.out.println(key + "->" + value);
//            }
//
//            List keyList = new ArrayList<>(tm.keySet());
//            List valueList = new ArrayList<>(tm.values());

            /*Map<Fish, Double> tms1 = new TreeMap<>(new Comparator<Fish>() {
                @Override
                public int compare(Fish o1, Fish o2) {
                    return (int) (o1.getPrice() * 100 - o2.getPrice() * 100);
                }
            });

            Fish f1 = new Fish("ell ", 1.5, 120);
            Fish f2 = new Fish("ell2 ", 2.5, 180);
            Fish f3 = new Fish("ell3 ", 3.5, 220);
            Fish f4 = new Fish("ell4 ", 2.5, 150);
            Fish f5 = new Fish("ell4 ", 2.5, 150);

             tms1.put(f1, 120.0);
             tms1.put(f2, 180.0);
             tms1.put(f3, 220.0);
             tms1.put(f4, 150.0);
             tms1.put(f5, 1000.0);
             for(Object eo : tms1.entrySet()){
                 Map.Entry e = (Map.Entry) eo;
                System.out.println(e.getKey() + "------>" + e.getValue());
            }*/


            //пример.1.-2я часть
       /* Map<Fish,Integer> map = new HashMap<>();
        Fish fish1 = new Fish("ell ", 1.5, 120);
        Fish fish2 = new Fish("ell2 ", 2.5, 180);
        Fish fish3 = new Fish("ell3 ", 3.5, 220);
        Fish fish4 = new Fish("ell4 ", 2.5, 150);
        Fish fish5 = new Fish("ell4 ", 2.5, 150);

        map.put(fish1, 120);
        map.put(fish2, 150);
        map.put(fish3, 220);
        map.put(fish4, 150);
        map.put(fish5, 100);

        for (Map.Entry <Fish,Integer> entry : map.entrySet()){
            Fish key= entry.getKey();
            int b = entry.getValue();
            System.out.println(key + "->" + b);*/
        }

        //Пример.3. Сборка мусора
        Map<Fish, Double> wtm = new WeakHashMap<>();
        Fish f1 = new Fish("ell ", 1.5, 120);
        Fish f2 = new Fish("ell2 ", 2.5, 180);
        Fish f3 = new Fish("ell3 ", 3.5, 220);

        wtm.put(f1, 120.0);
        wtm.put(f2, 180.0);
        wtm.put(f3, 220.0);
        System.out.println("Before: ");
        for (Object o : wtm.entrySet()) {
            Map.Entry e = (Map.Entry) o;
            System.out.println(e.getKey() + "--> " + e.getValue());
        }
        f2 = null;
        for (int i = 0; i > 1000; i++) {
            byte[] b = new byte[1000000];
            b = null;
        }
        System.out.println("After: ");
        for (Object o : wtm.entrySet()) {
            Map.Entry e = (Map.Entry) o;
            System.out.println(e.getKey() + "--> " + e.getValue());
        }

        //Задание.Создать коолекцию из класса автомобилейс параметрами имя, а цвет (ключ) и цена (ключ).
        //Значение это колличество автомобилей
        //Отсортировать и вывести в консоль
        //Удалить повторения

        class Car {
            String name;
            String color;
            double price;

            public Car(String name, String color, double price) {
                this.name = name;
                this.color = color;
                this.price = price;
            }

        }
        Map<Car, Integer> cr = new TreeMap<>();
        Car c1 = new Car("Lamborghini ", "Yellow", 200000);
        Car c2 = new Car("Bugatti ", "Black", 300000);
        Car c3 = new Car("Aston Matrin ", "Blue", 250000);

        cr.put(c1,3);
        cr.put(c2,2);
        cr.put(c3,1);

        for(Map.Entry e : cr.entrySet())
         {
         System.out.println(e.getKey() + " " + e.getValue());
         }

        Map<Car, Integer> cr = new TreeMap<>(new Comparator <Car>() {
            @Override
            public int compare(Car t1, Car t2) {
                return (int) (t1.getPrice() * 100 - t2.getPrice() * 100);
            }



      /* Iterator iterator = cr.entrySet().iterator();
       while(iterator.hasNext())

            {
               Map.Entry entry = (Map.Entry) iterator.hasNext();
               String key = (String) entry.getValue();
               String value = (String) entry.getValue();

              System.out.println(key + "->" + value);
           }*/


    }
}
}

